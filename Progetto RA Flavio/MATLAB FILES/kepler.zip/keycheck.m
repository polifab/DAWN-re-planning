function keycheck

% pause and request user input

fprintf('\n   < please press any key to continue >\n');

pause;
