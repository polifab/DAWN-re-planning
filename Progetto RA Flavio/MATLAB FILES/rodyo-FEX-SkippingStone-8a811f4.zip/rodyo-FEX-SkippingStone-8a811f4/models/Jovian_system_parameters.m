function [model, constants] = Jovian_system_parameters(model, constants)
    %??? to be implemented later
end