function [model, constants] = planetary_atmospheres_model(seq, model, constants)
    % ??? to be implemented later
end