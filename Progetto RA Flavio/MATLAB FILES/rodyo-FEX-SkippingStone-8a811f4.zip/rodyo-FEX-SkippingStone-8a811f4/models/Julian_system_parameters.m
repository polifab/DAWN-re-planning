function [model, constants] = Julian_system_parameters(model, constants)
    % ??? to be implemented later
end