function [model, constants] = Jovian_system_model(model, constants)
    %??? to be implemented later
end