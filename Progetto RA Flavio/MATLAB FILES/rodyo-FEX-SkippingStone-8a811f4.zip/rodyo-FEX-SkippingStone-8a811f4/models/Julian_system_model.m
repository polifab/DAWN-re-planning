function [model, constants] = Julian_system_model
    % ??? to be implemented later
end