function [model, constants] = planetary_atmospheres_parameters(model, constants)
    %??? to be implemented later    
end
