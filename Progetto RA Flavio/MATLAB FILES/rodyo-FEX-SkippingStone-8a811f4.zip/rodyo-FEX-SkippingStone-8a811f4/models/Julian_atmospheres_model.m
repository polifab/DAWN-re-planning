function [model, constants] = Julian_atmospheres_model(model, constants)
    %??? to be implemented later
end