function [model, constants] = Jovian_atmospheres_model(model, constants)
    %??? to be implemented later
end