function model = user_Julian_system_parameters(model)
    % no modifications -- empty function
end