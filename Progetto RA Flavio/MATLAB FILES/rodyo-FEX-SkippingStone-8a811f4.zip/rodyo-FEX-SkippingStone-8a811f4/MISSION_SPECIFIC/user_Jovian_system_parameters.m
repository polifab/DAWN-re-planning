function model = user_Jovian_system_parameters(model)
    % no modifications -- empty function
end