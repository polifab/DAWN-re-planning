Mars  		HORIZONS ephemerides not available after 03-Jan-2100
Jupiter		HORIZONS ephemerides not available after 01-Jan-2099
Uranus  	HORIZONS ephemerides not available after 23-Dec-2099