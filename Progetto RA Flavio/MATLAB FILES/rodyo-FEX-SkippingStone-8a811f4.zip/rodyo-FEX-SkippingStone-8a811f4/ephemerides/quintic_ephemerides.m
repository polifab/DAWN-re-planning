function varargout = quintic_ephemerides(seq, model, environment, type, times, mode)    
    %??? to be implemented    
end